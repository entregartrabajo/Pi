var mysql = require('mysql');
var express = require('express');
const bodyParser = require('body-parser');
var app = express();
var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "Sevilla",
  port: 3304,
  database: "pi"
});



con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to MySQL!");
});
 
 
 
 
 
 
 
 
 
 
app.get('/comprobar-conexion', function(req, res) {
  if (con.state === 'disconnected') {
    res.send('Error: No se pudo conectar a MySQL');
  } else {
    res.send('Conexión a MySQL establecida correctamente');
  }
});
//app.use(express.urlencoded());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Parse JSON bodies (as sent by API clients)
//app.use(express.json());
app.post('/comprobar-usuario', function(req, res) {
  var username = req.body.username;
  var password = req.body.password;

  con.query("SELECT usuario, contrasena FROM usuarios WHERE usuario = ? AND contrasena = ?", [username, password], function(err, result, fields) {
    if (err) throw err;
    console.log(result);

    if (con.state === 'disconnected') {
      res.send('{"respuesta":"Error no puede conectarse  a sql"}');
    } else {
      if (result.length > 0) {
        res.writeHead(200, {
					'Content-Type': 'application/json','Access-Control-Allow-Origin': '*'
				}).end(JSON.stringify({respuesta: "UsuarioCorrecto" }));
				
      } else {
        res.writeHead(200, {
					'Content-Type': 'application/json','Access-Control-Allow-Origin': '*'
				}).end(JSON.stringify({respuesta: "UsuarioIncorrecto" }));
        
      }
    }
  });
});



app.post('/insertar', function(req, res) {
  // Datos de la incidencia a insertar
  const incidencia = {
    Fecha: req.body.Fecha,
   
    Umbral_radiacion: req.body.Umbral_radiacion,
    Valor_radiacion: req.body.Valor_radiacion
  };


  

    // Realizar la inserción de datos
    const sql = `INSERT INTO incidencia (Fecha, Umbral_radiacion, Valor_radiacion)
                 VALUES (?, ?, ?)`;

  con.query(sql, [incidencia.Fecha,  incidencia.Umbral_radiacion, incidencia.Valor_radiacion], function(err, result) {
      if (err) throw err;
      console.log('Datos insertados correctamente en la tabla incidencia.');
      
       res.writeHead(200, {
					'Content-Type': 'application/json','Access-Control-Allow-Origin': '*'
				}).end(JSON.stringify({respuesta: "Datos insertados" }));
    });
      
});
app.get('/exportar', function(req, res) {
  


  
  const sql =  `SELECT JSON_ARRAYAGG(JSON_OBJECT('umbral_radiacion', umbral_radiacion,'Fecha',Fecha,  'nivel_radiaccion',  Valor_radiacion ) ) as  resultado from
  (select umbral_radiacion,Fecha ,Valor_radiacion  from incidencia 
   order by Fecha desc  LIMIT 15) tabla`;
   

  con.query(sql, function(err, result) {
      if (err) throw err;
      console.log('Datos insertados correctamente en la tabla incidencia.');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
       res.writeHead(200, {
					'Content-Type': 'application/json','Access-Control-Allow-Origin': '*'
				}).end(JSON.stringify( result ));
    });
      
});

app.listen(3000, function() {
  console.log('Servidor iniciado en http://127.0.0.1:3000');
});
