CREATE DATABASE pi;
use pi;


CREATE TABLE Incidencia (
 Id_incidencia INT PRIMARY KEY AUTO_INCREMENT,
 Fecha DATE NOT NULL,
 Umbral_radiacion INT NOT NULL,
 Valor_radiacion FLOAT NOT NULL
);



CREATE TABLE usuarios (
 id INT NOT NULL AUTO_INCREMENT,
 usuario VARCHAR(50) NOT NULL,
 contrasena VARCHAR(255) NOT NULL,
 PRIMARY KEY (id)
);
INSERT INTO usuarios (usuario, contrasena) VALUES
 ('usuario', 'mypass'),
 ('usuario2', 'usuario');